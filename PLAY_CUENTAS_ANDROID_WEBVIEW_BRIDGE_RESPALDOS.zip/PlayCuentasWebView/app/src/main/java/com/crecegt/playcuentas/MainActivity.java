package com.crecegt.playcuentas;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {

    private static final String APP_URL = "https://94fr25-jpg.github.io/Pago/";
    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.setStatusBarColor(Color.BLACK);
        window.setNavigationBarColor(Color.BLACK);

        webView = new WebView(this);
        webView.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));
        webView.setBackgroundColor(Color.BLACK);
        setContentView(webView);

        configureWebView();

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(APP_URL);
        }
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        // Puente nativo para que el HTML pueda guardar respaldo JSON y copiar texto dentro de la APK.
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url == null) return false;

                if (url.startsWith("http://") || url.startsWith("https://")) {
                    view.loadUrl(url);
                    return true;
                }

                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                } catch (Exception ignored) {
                    Toast.makeText(MainActivity.this, "No se pudo abrir este enlace", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams
            ) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }

                MainActivity.this.filePathCallback = filePathCallback;

                Intent intent;
                try {
                    intent = fileChooserParams.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);

                    // Respetar el tipo de archivo pedido por el HTML.
                    // Antes se forzaba image/* y por eso NO permitía importar JSON.
                    String type = resolveMimeType(fileChooserParams.getAcceptTypes());
                    if (type != null && !type.isEmpty()) intent.setType(type);
                } catch (Exception e) {
                    intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                }

                try {
                    startActivityForResult(Intent.createChooser(intent, "Selecciona archivo"), FILE_CHOOSER_REQUEST_CODE);
                    return true;
                } catch (ActivityNotFoundException e) {
                    MainActivity.this.filePathCallback = null;
                    Toast.makeText(MainActivity.this, "No se encontró una app para seleccionar archivos", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
    }

    private String resolveMimeType(String[] acceptTypes) {
        if (acceptTypes == null || acceptTypes.length == 0) return "*/*";
        boolean hasImage = false;
        boolean hasJson = false;
        String firstRealType = "";

        for (String raw : acceptTypes) {
            if (raw == null) continue;
            String t = raw.trim().toLowerCase();
            if (t.isEmpty()) continue;
            if (firstRealType.isEmpty() && t.contains("/")) firstRealType = t;
            if (t.contains("image") || t.equals(".png") || t.equals(".jpg") || t.equals(".jpeg") || t.equals(".webp")) hasImage = true;
            if (t.contains("json") || t.equals(".json") || t.contains("text/plain")) hasJson = true;
        }

        if (hasJson) return "*/*";
        if (hasImage) return "image/*";
        if (!firstRealType.isEmpty()) return firstRealType;
        return "*/*";
    }

    public class AndroidBridge {
        @JavascriptInterface
        public String saveBackup(String fileName, String content) {
            try {
                String safeName = sanitizeFileName(fileName);
                if (!safeName.toLowerCase().endsWith(".json")) safeName += ".json";
                if (content == null) content = "";

                Uri savedUri;
                OutputStream outputStream;

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName);
                    values.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/PLAY_CUENTAS");
                    values.put(MediaStore.MediaColumns.IS_PENDING, 1);

                    savedUri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (savedUri == null) throw new Exception("No se pudo crear archivo");

                    outputStream = getContentResolver().openOutputStream(savedUri);
                    if (outputStream == null) throw new Exception("No se pudo abrir archivo");
                    outputStream.write(content.getBytes(StandardCharsets.UTF_8));
                    outputStream.close();

                    values.clear();
                    values.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    getContentResolver().update(savedUri, values, null, null);
                } else {
                    File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "PLAY_CUENTAS");
                    if (!dir.exists()) dir.mkdirs();
                    File file = new File(dir, safeName);
                    outputStream = new FileOutputStream(file);
                    outputStream.write(content.getBytes(StandardCharsets.UTF_8));
                    outputStream.close();
                    savedUri = Uri.fromFile(file);
                    MediaScannerConnection.scanFile(MainActivity.this, new String[]{file.getAbsolutePath()}, new String[]{"application/json"}, null);
                }

                toast("Respaldo guardado en Descargas/PLAY_CUENTAS");
                return savedUri.toString();
            } catch (Exception e) {
                toast("No se pudo guardar el respaldo");
                return "";
            }
        }

        @JavascriptInterface
        public boolean copyToClipboard(String text) {
            try {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard == null) return false;
                ClipData clip = ClipData.newPlainText("PLAY CUENTAS", text == null ? "" : text);
                clipboard.setPrimaryClip(clip);
                toast("Copiado");
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void toast(String message) {
            MainActivity.this.toast(message);
        }
    }

    private void toast(final String message) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
    }

    private String sanitizeFileName(String name) {
        String base = name == null ? "backup-play-cuentas.json" : name.trim();
        if (base.isEmpty()) base = "backup-play-cuentas.json";
        return base.replaceAll("[^a-zA-Z0-9._-]", "_");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (filePathCallback == null) return;

            Uri[] results = null;
            if (resultCode == RESULT_OK) {
                results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            }

            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }
}
