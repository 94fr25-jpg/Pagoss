# ProGuard rules. Keep empty for this simple WebView app.
