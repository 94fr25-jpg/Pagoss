# PLAY CUENTAS - Android WebView

APK WebView para cargar:

https://94fr25-jpg.github.io/Pago/

Incluye soporte para:

- WebView con JavaScript
- LocalStorage / DOM Storage
- Selector de archivos para `<input type="file" accept="image/*">`
- Botón atrás del teléfono
- Icono de aplicación PLAY CUENTAS

## Compilar con Android Studio

1. Abre Android Studio.
2. File > Open.
3. Selecciona esta carpeta: `PlayCuentasWebView`.
4. Espera que descargue Gradle y dependencias.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. El APK queda en:

`app/build/outputs/apk/debug/app-debug.apk`

## Compilar con GitHub Actions

1. Sube esta carpeta completa a un repositorio de GitHub.
2. Entra al repositorio > Actions.
3. Abre `Build Android APK`.
4. Presiona `Run workflow`.
5. Cuando termine, descarga el artifact `PLAY-CUENTAS-debug-apk`.

## Cambiar la URL

Abre:

`app/src/main/java/com/crecegt/playcuentas/MainActivity.java`

Cambia esta línea:

```java
private static final String APP_URL = "https://94fr25-jpg.github.io/Pago/";
```
